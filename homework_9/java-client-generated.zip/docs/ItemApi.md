# ItemApi

All URIs are relative to *https://virtserver.swaggerhub.com/geek_brans_student/TestCloudServise/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteItem**](ItemApi.md#deleteItem) | **DELETE** /Item/{ItemId} | Deletes a Item
[**findItemsByStatus**](ItemApi.md#findItemsByStatus) | **GET** /Item/findByStatus | Finds Items by status
[**findItemsByTags**](ItemApi.md#findItemsByTags) | **GET** /Item/findByTags | Finds Items by tags
[**getItemById**](ItemApi.md#getItemById) | **GET** /Item/{ItemId} | Find Item by ID
[**updateItem**](ItemApi.md#updateItem) | **PUT** /Item | Update an existing item
[**updateItemWithForm**](ItemApi.md#updateItemWithForm) | **POST** /Item/{ItemId} | Updates a Item in the store with form data
[**uploadFile**](ItemApi.md#uploadFile) | **POST** /Item/{ItemId}/uploadImage | uploads an image

<a name="deleteItem"></a>
# **deleteItem**
> deleteItem(itemId, apiKey)

Deletes a Item

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ItemApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: Itemstore_auth
OAuth Itemstore_auth = (OAuth) defaultClient.getAuthentication("Itemstore_auth");
Itemstore_auth.setAccessToken("YOUR ACCESS TOKEN");

ItemApi apiInstance = new ItemApi();
Long itemId = 789L; // Long | Item id to delete
String apiKey = "apiKey_example"; // String | 
try {
    apiInstance.deleteItem(itemId, apiKey);
} catch (ApiException e) {
    System.err.println("Exception when calling ItemApi#deleteItem");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **itemId** | **Long**| Item id to delete |
 **apiKey** | **String**|  | [optional]

### Return type

null (empty response body)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="findItemsByStatus"></a>
# **findItemsByStatus**
> List&lt;Item&gt; findItemsByStatus(status)

Finds Items by status

Multiple status values can be provided with comma separated strings

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ItemApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: Itemstore_auth
OAuth Itemstore_auth = (OAuth) defaultClient.getAuthentication("Itemstore_auth");
Itemstore_auth.setAccessToken("YOUR ACCESS TOKEN");

ItemApi apiInstance = new ItemApi();
List<String> status = Arrays.asList("status_example"); // List<String> | Status values that need to be considered for filter
try {
    List<Item> result = apiInstance.findItemsByStatus(status);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ItemApi#findItemsByStatus");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **status** | [**List&lt;String&gt;**](String.md)| Status values that need to be considered for filter | [enum: available, pending, sold]

### Return type

[**List&lt;Item&gt;**](Item.md)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="findItemsByTags"></a>
# **findItemsByTags**
> List&lt;Item&gt; findItemsByTags(tags)

Finds Items by tags

Muliple tags can be provided with comma separated strings. Use\\ \\ tag1, tag2, tag3 for testing.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ItemApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: Itemstore_auth
OAuth Itemstore_auth = (OAuth) defaultClient.getAuthentication("Itemstore_auth");
Itemstore_auth.setAccessToken("YOUR ACCESS TOKEN");

ItemApi apiInstance = new ItemApi();
List<String> tags = Arrays.asList("tags_example"); // List<String> | Tags to filter by
try {
    List<Item> result = apiInstance.findItemsByTags(tags);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ItemApi#findItemsByTags");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tags** | [**List&lt;String&gt;**](String.md)| Tags to filter by |

### Return type

[**List&lt;Item&gt;**](Item.md)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getItemById"></a>
# **getItemById**
> Item getItemById(itemId)

Find Item by ID

Returns a single Item

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ItemApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

ItemApi apiInstance = new ItemApi();
Long itemId = 789L; // Long | ID of Item to return
try {
    Item result = apiInstance.getItemById(itemId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ItemApi#getItemById");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **itemId** | **Long**| ID of Item to return |

### Return type

[**Item**](Item.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="updateItem"></a>
# **updateItem**
> updateItem(body)

Update an existing item

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ItemApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: Itemstore_auth
OAuth Itemstore_auth = (OAuth) defaultClient.getAuthentication("Itemstore_auth");
Itemstore_auth.setAccessToken("YOUR ACCESS TOKEN");

ItemApi apiInstance = new ItemApi();
Item body = new Item(); // Item | Item object that needs to be added to the store
try {
    apiInstance.updateItem(body);
} catch (ApiException e) {
    System.err.println("Exception when calling ItemApi#updateItem");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Item**](Item.md)| Item object that needs to be added to the store |

### Return type

null (empty response body)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

<a name="updateItemWithForm"></a>
# **updateItemWithForm**
> updateItemWithForm(itemId, name, status)

Updates a Item in the store with form data

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ItemApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: Itemstore_auth
OAuth Itemstore_auth = (OAuth) defaultClient.getAuthentication("Itemstore_auth");
Itemstore_auth.setAccessToken("YOUR ACCESS TOKEN");

ItemApi apiInstance = new ItemApi();
Long itemId = 789L; // Long | ID of Item that needs to be updated
String name = "name_example"; // String | 
String status = "status_example"; // String | 
try {
    apiInstance.updateItemWithForm(itemId, name, status);
} catch (ApiException e) {
    System.err.println("Exception when calling ItemApi#updateItemWithForm");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **itemId** | **Long**| ID of Item that needs to be updated |
 **name** | **String**|  | [optional]
 **status** | **String**|  | [optional]

### Return type

null (empty response body)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: Not defined

<a name="uploadFile"></a>
# **uploadFile**
> ModelApiResponse uploadFile(itemId, body)

uploads an image

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ItemApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: Itemstore_auth
OAuth Itemstore_auth = (OAuth) defaultClient.getAuthentication("Itemstore_auth");
Itemstore_auth.setAccessToken("YOUR ACCESS TOKEN");

ItemApi apiInstance = new ItemApi();
Long itemId = 789L; // Long | ID of Item to update
Object body = null; // Object | 
try {
    ModelApiResponse result = apiInstance.uploadFile(itemId, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ItemApi#uploadFile");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **itemId** | **Long**| ID of Item to update |
 **body** | **Object**|  | [optional]

### Return type

[**ModelApiResponse**](ModelApiResponse.md)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: application/octet-stream
 - **Accept**: application/json

