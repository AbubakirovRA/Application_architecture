# Item

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**category** | [**\Swagger\Client\Model\Category**](Category.md) |  | [optional] 
**name** | **string** |  | [optional] 
**diagram** | **string[]** |  | 
**tags** | [**\Swagger\Client\Model\Tag[]**](Tag.md) |  | [optional] 
**status** | **string** | Item status in the store | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

