# CloudService.ItemItemIdBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Updated name of the Item | [optional] 
**status** | **String** | Updated status of the Item | [optional] 
