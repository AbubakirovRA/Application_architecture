# CloudService.ItemApi

All URIs are relative to *https://virtserver.swaggerhub.com/geek_brans_student/TestCloudServise/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteItem**](ItemApi.md#deleteItem) | **DELETE** /Item/{ItemId} | Deletes a Item
[**findItemsByStatus**](ItemApi.md#findItemsByStatus) | **GET** /Item/findByStatus | Finds Items by status
[**findItemsByTags**](ItemApi.md#findItemsByTags) | **GET** /Item/findByTags | Finds Items by tags
[**getItemById**](ItemApi.md#getItemById) | **GET** /Item/{ItemId} | Find Item by ID
[**updateItem**](ItemApi.md#updateItem) | **PUT** /Item | Update an existing item
[**updateItemWithForm**](ItemApi.md#updateItemWithForm) | **POST** /Item/{ItemId} | Updates a Item in the store with form data
[**uploadFile**](ItemApi.md#uploadFile) | **POST** /Item/{ItemId}/uploadImage | uploads an image

<a name="deleteItem"></a>
# **deleteItem**
> deleteItem(itemId, opts)

Deletes a Item

### Example
```javascript
import {CloudService} from 'cloud_service';
let defaultClient = CloudService.ApiClient.instance;

// Configure OAuth2 access token for authorization: Itemstore_auth
let Itemstore_auth = defaultClient.authentications['Itemstore_auth'];
Itemstore_auth.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new CloudService.ItemApi();
let itemId = 789; // Number | Item id to delete
let opts = { 
  'apiKey': "apiKey_example" // String | 
};
apiInstance.deleteItem(itemId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **itemId** | **Number**| Item id to delete | 
 **apiKey** | **String**|  | [optional] 

### Return type

null (empty response body)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="findItemsByStatus"></a>
# **findItemsByStatus**
> [Item] findItemsByStatus(status)

Finds Items by status

Multiple status values can be provided with comma separated strings

### Example
```javascript
import {CloudService} from 'cloud_service';
let defaultClient = CloudService.ApiClient.instance;

// Configure OAuth2 access token for authorization: Itemstore_auth
let Itemstore_auth = defaultClient.authentications['Itemstore_auth'];
Itemstore_auth.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new CloudService.ItemApi();
let status = ["status_example"]; // [String] | Status values that need to be considered for filter

apiInstance.findItemsByStatus(status, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **status** | [**[String]**](String.md)| Status values that need to be considered for filter | 

### Return type

[**[Item]**](Item.md)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="findItemsByTags"></a>
# **findItemsByTags**
> [Item] findItemsByTags(tags)

Finds Items by tags

Muliple tags can be provided with comma separated strings. Use\\ \\ tag1, tag2, tag3 for testing.

### Example
```javascript
import {CloudService} from 'cloud_service';
let defaultClient = CloudService.ApiClient.instance;

// Configure OAuth2 access token for authorization: Itemstore_auth
let Itemstore_auth = defaultClient.authentications['Itemstore_auth'];
Itemstore_auth.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new CloudService.ItemApi();
let tags = ["tags_example"]; // [String] | Tags to filter by

apiInstance.findItemsByTags(tags, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tags** | [**[String]**](String.md)| Tags to filter by | 

### Return type

[**[Item]**](Item.md)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getItemById"></a>
# **getItemById**
> Item getItemById(itemId)

Find Item by ID

Returns a single Item

### Example
```javascript
import {CloudService} from 'cloud_service';
let defaultClient = CloudService.ApiClient.instance;

// Configure API key authorization: api_key
let api_key = defaultClient.authentications['api_key'];
api_key.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.apiKeyPrefix = 'Token';

let apiInstance = new CloudService.ItemApi();
let itemId = 789; // Number | ID of Item to return

apiInstance.getItemById(itemId, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **itemId** | **Number**| ID of Item to return | 

### Return type

[**Item**](Item.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="updateItem"></a>
# **updateItem**
> updateItem(body)

Update an existing item

### Example
```javascript
import {CloudService} from 'cloud_service';
let defaultClient = CloudService.ApiClient.instance;

// Configure OAuth2 access token for authorization: Itemstore_auth
let Itemstore_auth = defaultClient.authentications['Itemstore_auth'];
Itemstore_auth.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new CloudService.ItemApi();
let body = new CloudService.Item(); // Item | Item object that needs to be added to the store

apiInstance.updateItem(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Item**](Item.md)| Item object that needs to be added to the store | 

### Return type

null (empty response body)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

<a name="updateItemWithForm"></a>
# **updateItemWithForm**
> updateItemWithForm(itemId, opts)

Updates a Item in the store with form data

### Example
```javascript
import {CloudService} from 'cloud_service';
let defaultClient = CloudService.ApiClient.instance;

// Configure OAuth2 access token for authorization: Itemstore_auth
let Itemstore_auth = defaultClient.authentications['Itemstore_auth'];
Itemstore_auth.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new CloudService.ItemApi();
let itemId = 789; // Number | ID of Item that needs to be updated
let opts = { 
  'name': "name_example", // String | 
  'status': "status_example" // String | 
};
apiInstance.updateItemWithForm(itemId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **itemId** | **Number**| ID of Item that needs to be updated | 
 **name** | **String**|  | [optional] 
 **status** | **String**|  | [optional] 

### Return type

null (empty response body)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: Not defined

<a name="uploadFile"></a>
# **uploadFile**
> ApiResponse uploadFile(itemId, opts)

uploads an image

### Example
```javascript
import {CloudService} from 'cloud_service';
let defaultClient = CloudService.ApiClient.instance;

// Configure OAuth2 access token for authorization: Itemstore_auth
let Itemstore_auth = defaultClient.authentications['Itemstore_auth'];
Itemstore_auth.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new CloudService.ItemApi();
let itemId = 789; // Number | ID of Item to update
let opts = { 
  'body': null // Object | 
};
apiInstance.uploadFile(itemId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **itemId** | **Number**| ID of Item to update | 
 **body** | [**Object**](Object.md)|  | [optional] 

### Return type

[**ApiResponse**](ApiResponse.md)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: application/octet-stream
 - **Accept**: application/json

