# CloudService.CloudResourceApi

All URIs are relative to *https://virtserver.swaggerhub.com/geek_brans_student/TestCloudServise/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addItem**](CloudResourceApi.md#addItem) | **POST** /Item | Add a new  resource of cloud  service to the store

<a name="addItem"></a>
# **addItem**
> addItem(body)

Add a new  resource of cloud  service to the store

### Example
```javascript
import {CloudService} from 'cloud_service';
let defaultClient = CloudService.ApiClient.instance;

// Configure OAuth2 access token for authorization: Itemstore_auth
let Itemstore_auth = defaultClient.authentications['Itemstore_auth'];
Itemstore_auth.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new CloudService.CloudResourceApi();
let body = new CloudService.Item(); // Item | Item object that needs to be added to the store

apiInstance.addItem(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Item**](Item.md)| Item object that needs to be added to the store | 

### Return type

null (empty response body)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

