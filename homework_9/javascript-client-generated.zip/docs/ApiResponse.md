# CloudService.ApiResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Number** |  | [optional] 
**type** | **String** |  | [optional] 
**message** | **String** |  | [optional] 
