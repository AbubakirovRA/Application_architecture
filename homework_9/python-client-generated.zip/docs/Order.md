# Order

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**item_id** | **int** |  | [optional] 
**quantity** | **int** |  | [optional] 
**ship_date** | **datetime** |  | [optional] 
**status** | **str** | Order Status | [optional] 
**complete** | **bool** |  | [optional] [default to False]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

