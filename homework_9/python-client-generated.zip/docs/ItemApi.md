# swagger_client.ItemApi

All URIs are relative to *https://virtserver.swaggerhub.com/geek_brans_student/TestCloudServise/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_item**](ItemApi.md#delete_item) | **DELETE** /Item/{ItemId} | Deletes a Item
[**find_items_by_status**](ItemApi.md#find_items_by_status) | **GET** /Item/findByStatus | Finds Items by status
[**find_items_by_tags**](ItemApi.md#find_items_by_tags) | **GET** /Item/findByTags | Finds Items by tags
[**get_item_by_id**](ItemApi.md#get_item_by_id) | **GET** /Item/{ItemId} | Find Item by ID
[**update_item**](ItemApi.md#update_item) | **PUT** /Item | Update an existing item
[**update_item_with_form**](ItemApi.md#update_item_with_form) | **POST** /Item/{ItemId} | Updates a Item in the store with form data
[**upload_file**](ItemApi.md#upload_file) | **POST** /Item/{ItemId}/uploadImage | uploads an image

# **delete_item**
> delete_item(item_id, api_key=api_key)

Deletes a Item

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: Itemstore_auth
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ItemApi(swagger_client.ApiClient(configuration))
item_id = 789 # int | Item id to delete
api_key = 'api_key_example' # str |  (optional)

try:
    # Deletes a Item
    api_instance.delete_item(item_id, api_key=api_key)
except ApiException as e:
    print("Exception when calling ItemApi->delete_item: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **item_id** | **int**| Item id to delete | 
 **api_key** | **str**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **find_items_by_status**
> list[Item] find_items_by_status(status)

Finds Items by status

Multiple status values can be provided with comma separated strings

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: Itemstore_auth
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ItemApi(swagger_client.ApiClient(configuration))
status = ['status_example'] # list[str] | Status values that need to be considered for filter

try:
    # Finds Items by status
    api_response = api_instance.find_items_by_status(status)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ItemApi->find_items_by_status: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **status** | [**list[str]**](str.md)| Status values that need to be considered for filter | 

### Return type

[**list[Item]**](Item.md)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **find_items_by_tags**
> list[Item] find_items_by_tags(tags)

Finds Items by tags

Muliple tags can be provided with comma separated strings. Use\\ \\ tag1, tag2, tag3 for testing.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: Itemstore_auth
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ItemApi(swagger_client.ApiClient(configuration))
tags = ['tags_example'] # list[str] | Tags to filter by

try:
    # Finds Items by tags
    api_response = api_instance.find_items_by_tags(tags)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ItemApi->find_items_by_tags: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tags** | [**list[str]**](str.md)| Tags to filter by | 

### Return type

[**list[Item]**](Item.md)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_item_by_id**
> Item get_item_by_id(item_id)

Find Item by ID

Returns a single Item

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: api_key
configuration = swagger_client.Configuration()
configuration.api_key['api_key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['api_key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ItemApi(swagger_client.ApiClient(configuration))
item_id = 789 # int | ID of Item to return

try:
    # Find Item by ID
    api_response = api_instance.get_item_by_id(item_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ItemApi->get_item_by_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **item_id** | **int**| ID of Item to return | 

### Return type

[**Item**](Item.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_item**
> update_item(body)

Update an existing item

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: Itemstore_auth
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ItemApi(swagger_client.ApiClient(configuration))
body = swagger_client.Item() # Item | Item object that needs to be added to the store

try:
    # Update an existing item
    api_instance.update_item(body)
except ApiException as e:
    print("Exception when calling ItemApi->update_item: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Item**](Item.md)| Item object that needs to be added to the store | 

### Return type

void (empty response body)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_item_with_form**
> update_item_with_form(item_id, name=name, status=status)

Updates a Item in the store with form data

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: Itemstore_auth
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ItemApi(swagger_client.ApiClient(configuration))
item_id = 789 # int | ID of Item that needs to be updated
name = 'name_example' # str |  (optional)
status = 'status_example' # str |  (optional)

try:
    # Updates a Item in the store with form data
    api_instance.update_item_with_form(item_id, name=name, status=status)
except ApiException as e:
    print("Exception when calling ItemApi->update_item_with_form: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **item_id** | **int**| ID of Item that needs to be updated | 
 **name** | **str**|  | [optional] 
 **status** | **str**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upload_file**
> ApiResponse upload_file(item_id, body=body)

uploads an image

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: Itemstore_auth
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ItemApi(swagger_client.ApiClient(configuration))
item_id = 789 # int | ID of Item to update
body = swagger_client.Object() # Object |  (optional)

try:
    # uploads an image
    api_response = api_instance.upload_file(item_id, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ItemApi->upload_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **item_id** | **int**| ID of Item to update | 
 **body** | **Object**|  | [optional] 

### Return type

[**ApiResponse**](ApiResponse.md)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: application/octet-stream
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

