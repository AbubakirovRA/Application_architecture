# Item

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**category** | [**Category**](Category.md) |  | [optional] 
**name** | **str** |  | [optional] 
**diagram** | **list[str]** |  | 
**tags** | [**list[Tag]**](Tag.md) |  | [optional] 
**status** | **str** | Item status in the store | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

