# swagger_client.CloudResourceApi

All URIs are relative to *https://virtserver.swaggerhub.com/geek_brans_student/TestCloudServise/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_item**](CloudResourceApi.md#add_item) | **POST** /Item | Add a new  resource of cloud  service to the store

# **add_item**
> add_item(body)

Add a new  resource of cloud  service to the store

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: Itemstore_auth
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.CloudResourceApi(swagger_client.ApiClient(configuration))
body = swagger_client.Item() # Item | Item object that needs to be added to the store

try:
    # Add a new  resource of cloud  service to the store
    api_instance.add_item(body)
except ApiException as e:
    print("Exception when calling CloudResourceApi->add_item: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Item**](Item.md)| Item object that needs to be added to the store | 

### Return type

void (empty response body)

### Authorization

[Itemstore_auth](../README.md#Itemstore_auth)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

